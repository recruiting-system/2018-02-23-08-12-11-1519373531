module.exports = function main() {
    console.log('Hello World!');
}